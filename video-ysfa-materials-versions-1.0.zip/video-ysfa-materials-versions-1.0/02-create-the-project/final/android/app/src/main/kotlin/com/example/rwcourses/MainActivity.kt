package com.example.rwcourses

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
